<<?php 
include("dbconfig/config.php");
$id=$_GET['pid'];
$query="DELETE FROM entryproduct WHERE id=''";

$data=mysql_query($con,$query);

if ($data) 
{
	echo "Record deleted from database";
	# code...
}
else
{
	echo "Failed deleted from database";
}
 ?>
