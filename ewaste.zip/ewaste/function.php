<?php
	session_start();
	
		class functions
		{
			private $con;
			function __construct()
			{
				$this->con = new mysqli("localhost","root","","userlogin");
			
			}	

			function delete_product_by_id($delete_id)
			{
				if($stmt_delete = $this->con->prepare("delete FROM `entryproduct` where `id` = ?"))
				{
					$stmt_delete->bind_param("i",$delete_id);
				
					if($stmt_delete->execute())
					{
					return false;
					}
				}
			}
		}
?> 